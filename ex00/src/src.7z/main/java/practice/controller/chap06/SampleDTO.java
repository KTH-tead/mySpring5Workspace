package practice.controller.chap06;

import lombok.Data;

@Data
public class SampleDTO {
	private String name ;
	private int age ;

}
